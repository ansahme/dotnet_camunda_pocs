# YARP Proxy Setup Guide - Network Delay Simulation for Camunda

## What Was Created

This project demonstrates a complete .NET 10 YARP reverse proxy implementation with network delay simulation capabilities, specifically configured to forward requests to Camunda Run.

## Project Structure

```
/workspace/
├── .gitignore                      # Root gitignore
├── README.md                       # Project overview
├── SETUP_GUIDE.md                  # This file
└── CamundaProxy/                   # Main application
    ├── .gitignore                  # Project-specific gitignore
    ├── CamundaProxy.csproj         # .NET 10 project file with YARP
    ├── Program.cs                  # Main application with YARP configuration
    ├── DelaySimulationMiddleware.cs # Custom middleware for delay simulation
    ├── appsettings.json            # Production configuration
    ├── appsettings.Development.json # Development configuration
    ├── appsettings.Examples.json   # Example delay configurations
    ├── test-proxy.sh               # Test script
    ├── README.md                   # Detailed documentation
    └── Properties/
        └── launchSettings.json     # Launch profiles
```

## Key Components

### 1. DelaySimulationMiddleware.cs

Custom ASP.NET Core middleware that intercepts requests and adds configurable delays:

- **Fixed delays**: Constant latency (e.g., always 1000ms)
- **Random delays**: Variable latency within a range (e.g., 500-3000ms)
- **Enable/disable**: Toggle delays via configuration
- **Logging**: All delays are logged for debugging

**Features:**
```csharp
public class DelaySimulationOptions
{
    public bool Enabled { get; set; }
    public bool UseRandomDelay { get; set; }
    public int FixedDelayMs { get; set; }
    public int MinDelayMs { get; set; }
    public int MaxDelayMs { get; set; }
}
```

### 2. Program.cs

Main application entry point that:
- Configures YARP reverse proxy
- Loads configuration from appsettings.json
- Registers delay simulation middleware
- Sets up health check endpoint
- Maps reverse proxy routes

### 3. Configuration Files

#### appsettings.json (Production)
- Fixed 1000ms delay
- Routes all traffic to `http://localhost:8080`
- Standard logging

#### appsettings.Development.json
- Random delays (200-2000ms)
- Verbose logging
- Same Camunda routing

#### appsettings.Examples.json
Demonstrates 6 different scenarios:
1. No delay (production mode)
2. Fixed 1-second delay
3. Random 500-3000ms delay
4. Slow network (2-5 seconds)
5. Timeout testing (30 seconds)
6. Realistic latency (50-200ms)

## Quick Start

### Option 1: Run Locally

**Prerequisites:**
- .NET 10 SDK installed
- Camunda Run running on port 8080

**Steps:**
```bash
# 1. Navigate to project
cd /workspace/CamundaProxy

# 2. Restore dependencies
dotnet restore

# 3. Build project
dotnet build

# 4. Run proxy
dotnet run
```

**Access:**
- Proxy: http://localhost:5000
- Health: http://localhost:5000/health
- Camunda via proxy: http://localhost:5000/engine-rest/version

## Testing the Proxy

### 1. Health Check
```bash
curl http://localhost:5000/health
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2025-12-10T...",
  "delaySimulation": {
    "enabled": true,
    "useRandomDelay": false,
    "fixedDelayMs": 1000,
    "minDelayMs": 500,
    "maxDelayMs": 3000
  }
}
```

### 2. Proxy Request
```bash
curl http://localhost:5000/engine-rest/version
```

Expected behavior:
- 1000ms delay (or random if configured)
- Response from Camunda
- Logged delay information

### 3. Run Test Script
```bash
cd /workspace/CamundaProxy
./test-proxy.sh
```

This script:
- Tests health check
- Makes requests through proxy
- Measures response times
- Shows delay variations

## Configuration Guide

### Changing Delay Settings

Edit `CamundaProxy/appsettings.json`:

```json
{
  "DelaySimulation": {
    "Enabled": true,           // Turn on/off
    "UseRandomDelay": false,   // Fixed or random
    "FixedDelayMs": 1000,      // Used when UseRandomDelay=false
    "MinDelayMs": 500,         // Used when UseRandomDelay=true
    "MaxDelayMs": 3000         // Used when UseRandomDelay=true
  }
}
```

### Changing Camunda Target

Edit `CamundaProxy/appsettings.json`:

```json
{
  "ReverseProxy": {
    "Clusters": {
      "camunda-cluster": {
        "Destinations": {
          "camunda-instance": {
            "Address": "http://localhost:8080"  // Change this
          }
        }
      }
    }
  }
}
```

### Environment-Specific Settings

Use different appsettings files:

```bash
# Use Development settings (random delays)
dotnet run --environment Development

# Use Production settings (fixed delays)
dotnet run --environment Production
```

## Use Cases

### 1. Testing Application Resilience
**Goal:** See how your app handles slow Camunda responses

**Configuration:**
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 1000,
    "MaxDelayMs": 5000
  }
}
```

**Usage:**
- Point your application to proxy instead of Camunda
- Run your test suite
- Observe timeout handling, retry logic, user feedback

### 2. Load Testing with Realistic Latency
**Goal:** Add network latency to load tests

**Configuration:**
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 50,
    "MaxDelayMs": 200
  }
}
```

**Usage:**
- Configure load testing tool to use proxy
- Run load tests
- Measure performance under realistic conditions

### 3. Timeout Configuration
**Goal:** Find optimal timeout values

**Configuration:**
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 30000
  }
}
```

**Usage:**
- Gradually increase FixedDelayMs
- Find when your application times out
- Configure appropriate timeout values

### 4. Development Environment
**Goal:** Simulate production conditions locally

**Configuration:**
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 100,
    "MaxDelayMs": 500
  }
}
```

**Usage:**
- Always run through proxy during development
- Catch latency-related issues early
- Better production readiness

## How It Works

### Request Flow

```
Client Application
       ↓
    [Request]
       ↓
YARP Proxy (localhost:5000)
       ↓
[Delay Simulation Middleware]
  - Reads configuration
  - Calculates delay (fixed or random)
  - Logs delay value
  - Waits for delay duration
       ↓
[YARP Routing]
  - Forwards request to Camunda
       ↓
Camunda Run (localhost:8080)
  - Processes request
  - Returns response
       ↓
[YARP Proxy]
  - Returns response to client
       ↓
[Delay Simulation Middleware]
  - (Response phase - no delay)
       ↓
Client Application
```

### Middleware Order

Important: Delay middleware runs **before** YARP routing:

```csharp
app.UseDelaySimulation(...);  // 1. Add delay
app.MapReverseProxy();        // 2. Forward request
```

This means:
- Delay is added to request
- Camunda processing time is separate
- Total time = Delay + Camunda processing

## Troubleshooting

### Problem: Proxy won't start

**Solution:**
```bash
# Check if .NET 10 is installed
dotnet --version

# Should output: 10.0.xxx

# Restore packages
cd /workspace/CamundaProxy
dotnet restore
```

### Problem: Can't reach Camunda through proxy

**Checklist:**
1. Is Camunda running?
   ```bash
   curl http://localhost:8080/engine-rest/version
   ```
2. Is proxy running?
   ```bash
   curl http://localhost:5000/health
   ```
3. Check proxy configuration in appsettings.json
4. Check proxy logs for errors

### Problem: No delays are applied

**Solutions:**
1. Verify `Enabled: true` in DelaySimulation section
2. Check logs - should see "Simulating network delay" messages
3. Ensure you're accessing through proxy (port 5000) not Camunda direct (port 8080)

### Problem: Port already in use

**Solutions:**
```bash
# Check what's using port 5000
lsof -i :5000

# Change proxy port in launchSettings.json
# Or use environment variable
ASPNETCORE_URLS="http://localhost:5555" dotnet run
```

## Advanced Scenarios

### Multiple Camunda Instances (Load Balancing)

Edit `appsettings.json`:

```json
{
  "ReverseProxy": {
    "Clusters": {
      "camunda-cluster": {
        "LoadBalancingPolicy": "RoundRobin",
        "Destinations": {
          "camunda-1": { "Address": "http://localhost:8080" },
          "camunda-2": { "Address": "http://localhost:8081" },
          "camunda-3": { "Address": "http://localhost:8082" }
        }
      }
    }
  }
}
```

### Route-Specific Configuration

```json
{
  "ReverseProxy": {
    "Routes": {
      "api-route": {
        "ClusterId": "camunda-cluster",
        "Match": { "Path": "/engine-rest/{**catch-all}" }
      },
      "web-route": {
        "ClusterId": "camunda-cluster",
        "Match": { "Path": "/camunda/{**catch-all}" }
      }
    }
  }
}
```

### Per-Environment Delays

Create `appsettings.Staging.json`:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 300,
    "MaxDelayMs": 1000
  }
}
```

Run with:
```bash
dotnet run --environment Staging
```

## Extending the Project

### Add Request/Response Logging

Create `LoggingMiddleware.cs`:

```csharp
public class LoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<LoggingMiddleware> _logger;

    public LoggingMiddleware(RequestDelegate next, ILogger<LoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        _logger.LogInformation("Request: {Method} {Path}", 
            context.Request.Method, 
            context.Request.Path);
        
        await _next(context);
        
        _logger.LogInformation("Response: {StatusCode}", 
            context.Response.StatusCode);
    }
}
```

### Add Metrics

Install package:
```bash
dotnet add package Prometheus.Client.AspNetCore
```

Add to Program.cs:
```csharp
app.UseMetricServer();
app.UseMiddleware<ProxyMetricsMiddleware>();
```

### Add Authentication

```csharp
builder.Services.AddAuthentication()
    .AddJwtBearer(options => { /* config */ });

app.UseAuthentication();
app.UseAuthorization();
```

## Performance Considerations

### Memory Usage
- Minimal overhead: ~50-100 MB
- Scales with concurrent requests
- No state maintained between requests

### CPU Usage
- Very low: mostly idle
- Spike during delay calculation (negligible)
- YARP forwarding is highly optimized

### Latency
- Added latency = configured delay
- YARP overhead: ~1-5ms
- Total = Delay + YARP + Camunda processing

## Security Notes

### Production Deployment

1. **Remove or disable delays in production:**
   ```json
   { "DelaySimulation": { "Enabled": false } }
   ```

2. **Use HTTPS:**
   ```bash
   dotnet dev-certs https --trust
   ```

3. **Configure authentication if needed**

4. **Use environment variables for sensitive config:**
   ```bash
   export ReverseProxy__Clusters__camunda-cluster__Destinations__camunda-instance__Address="https://prod-camunda:8080"
   ```

5. **Enable request size limits**

6. **Configure CORS if needed**

## Additional Resources

### Documentation
- [YARP Official Docs](https://microsoft.github.io/reverse-proxy/)
- [ASP.NET Core Middleware](https://learn.microsoft.com/aspnet/core/fundamentals/middleware/)
- [Camunda REST API](https://docs.camunda.io/docs/apis-tools/camunda-api-rest/camunda-api-rest-overview/)

### Example API Calls

```bash
# Get Camunda version
curl http://localhost:5000/engine-rest/version

# Get process definitions
curl http://localhost:5000/engine-rest/process-definition

# Get deployment info
curl http://localhost:5000/engine-rest/deployment

# Start process instance
curl -X POST http://localhost:5000/engine-rest/process-definition/key/YOUR_PROCESS/start \
  -H "Content-Type: application/json" \
  -d '{}'
```

## Summary

You now have a fully functional YARP reverse proxy with:

✅ Network delay simulation (fixed and random)
✅ Configurable through appsettings.json
✅ Health check endpoint
✅ Logging and monitoring
✅ Test scripts
✅ Comprehensive documentation

**Next Steps:**
1. Start Camunda Run
2. Run the proxy: `dotnet run`
3. Test with: `./test-proxy.sh`
4. Experiment with different delay configurations
5. Integrate with your applications

**Happy Testing!** 🚀
