# Architecture Overview

## System Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                         Client Application                        │
│                    (Your Camunda-based App)                       │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            │ HTTP Request
                            │
                            ↓
┌──────────────────────────────────────────────────────────────────┐
│                    YARP Proxy (localhost:5000)                    │
│ ┌────────────────────────────────────────────────────────────────┤
│ │                  ASP.NET Core Pipeline                         │
│ │                                                                │
│ │  ┌──────────────────────────────────────────────────────────┐ │
│ │  │  Health Check Endpoint                                   │ │
│ │  │  GET /health → Returns proxy status & delay config      │ │
│ │  └──────────────────────────────────────────────────────────┘ │
│ │                          │                                     │
│ │                          ↓                                     │
│ │  ┌──────────────────────────────────────────────────────────┐ │
│ │  │  DelaySimulationMiddleware                               │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ 1. Read Configuration (appsettings.json)          │  │ │
│ │  │  │    - Enabled: true/false                          │  │ │
│ │  │  │    - UseRandomDelay: true/false                   │  │ │
│ │  │  │    - FixedDelayMs or MinDelayMs/MaxDelayMs        │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ 2. Calculate Delay                                │  │ │
│ │  │  │    - If random: Random.Shared.Next(min, max)      │  │ │
│ │  │  │    - If fixed: Use FixedDelayMs                   │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ 3. Log Delay                                      │  │ │
│ │  │  │    - Log method, path, and delay value            │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ 4. Apply Delay                                    │  │ │
│ │  │  │    - await Task.Delay(delayMs)                    │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  └──────────────────────────────────────────────────────────┘ │
│ │                          │                                     │
│ │                          ↓                                     │
│ │  ┌──────────────────────────────────────────────────────────┐ │
│ │  │  YARP Reverse Proxy                                      │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ Route Matching                                     │  │ │
│ │  │  │ - Path: {**catch-all}                              │  │ │
│ │  │  │ - Matches all incoming requests                    │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ Cluster Resolution                                 │  │ │
│ │  │  │ - Cluster: camunda-cluster                         │  │ │
│ │  │  │ - Destination: camunda-instance                    │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  │  ┌────────────────────────────────────────────────────┐  │ │
│ │  │  │ Request Forwarding                                 │  │ │
│ │  │  │ - Forward to: http://localhost:8080                │  │ │
│ │  │  │ - Preserve headers, query strings, body            │  │ │
│ │  │  └────────────────────────────────────────────────────┘  │ │
│ │  └──────────────────────────────────────────────────────────┘ │
│ └────────────────────────────────────────────────────────────────┘
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            │ Forwarded Request
                            │
                            ↓
┌──────────────────────────────────────────────────────────────────┐
│                  Camunda Run (localhost:8080)                     │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  Camunda REST API                                          │  │
│  │  - /engine-rest/version                                    │  │
│  │  - /engine-rest/process-definition                         │  │
│  │  - /engine-rest/deployment                                 │  │
│  │  - ... (all Camunda endpoints)                             │  │
│  └────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            │ Response
                            │
                            ↓
┌──────────────────────────────────────────────────────────────────┐
│                    YARP Proxy (localhost:5000)                    │
│                    Returns response to client                     │
└───────────────────────────┬──────────────────────────────────────┘
                            │
                            │ HTTP Response
                            │
                            ↓
┌──────────────────────────────────────────────────────────────────┐
│                         Client Application                        │
│                     Receives delayed response                     │
└──────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Client Application
- Your application that needs to communicate with Camunda
- Points to proxy (localhost:5000) instead of Camunda (localhost:8080)
- Experiences simulated network delays

### 2. YARP Proxy
**Technology**: ASP.NET Core + YARP

**Components**:
- **Health Check Endpoint**: Monitoring and configuration visibility
- **Delay Middleware**: Custom middleware for delay simulation
- **YARP Engine**: Microsoft's reverse proxy library

**Ports**:
- HTTP: 5000
- HTTPS: 5001 (if configured)

### 3. DelaySimulationMiddleware
**Purpose**: Simulate network latency

**Algorithm**:
```
if (Enabled) {
    delay = UseRandomDelay 
        ? Random.Shared.Next(MinDelayMs, MaxDelayMs)
        : FixedDelayMs;
    
    Log("Simulating {delay}ms delay for {method} {path}");
    await Task.Delay(delay);
}
```

**Configuration**:
- Loaded from `appsettings.json`
- Can vary by environment (Development, Production, etc.)

### 4. YARP Routing
**Configuration**:
```json
{
  "Routes": {
    "camunda-route": {
      "ClusterId": "camunda-cluster",
      "Match": { "Path": "{**catch-all}" }
    }
  },
  "Clusters": {
    "camunda-cluster": {
      "Destinations": {
        "camunda-instance": { 
          "Address": "http://localhost:8080" 
        }
      }
    }
  }
}
```

**Features**:
- Matches all paths (`{**catch-all}`)
- Forwards to single destination (can be extended to multiple)
- Preserves all headers, query strings, and body content

### 5. Camunda Run
**Technology**: Camunda Platform Runtime

**Default Port**: 8080

**Endpoints**:
- `/engine-rest/*` - REST API
- `/camunda/*` - Web applications

## Data Flow

### Request Phase

```
Client Request
    ↓
[Routing] → Health check? → Return status JSON
    ↓
[Routing] → Normal request? ↓
    ↓
[Delay Middleware]
    ├─ Read config
    ├─ Calculate delay
    ├─ Log delay
    └─ Task.Delay(ms)
    ↓
[YARP Proxy]
    ├─ Match route
    ├─ Select destination
    └─ Forward request
    ↓
[Camunda Run]
    ├─ Process request
    └─ Generate response
```

### Response Phase

```
[Camunda Run]
    └─ Return response
    ↓
[YARP Proxy]
    └─ Forward response
    ↓
[Client]
    └─ Receive response
```

## Timing Analysis

### Total Response Time Breakdown

```
┌─────────────────────────────────────────────────────────────┐
│ Total Response Time                                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────────────────────────┐                  │
│  │ Simulated Delay                      │  (configurable)  │
│  │ - Fixed: FixedDelayMs                │                  │
│  │ - Random: MinDelayMs to MaxDelayMs   │                  │
│  └──────────────────────────────────────┘                  │
│              +                                              │
│  ┌──────────────────────────────────────┐                  │
│  │ YARP Overhead                        │  (~1-5ms)        │
│  │ - Route matching                     │                  │
│  │ - Request forwarding                 │                  │
│  │ - Response handling                  │                  │
│  └──────────────────────────────────────┘                  │
│              +                                              │
│  ┌──────────────────────────────────────┐                  │
│  │ Camunda Processing                   │  (variable)      │
│  │ - Endpoint processing                │                  │
│  │ - Database queries                   │                  │
│  │ - Business logic                     │                  │
│  └──────────────────────────────────────┘                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example:
- Simulated Delay: 1000ms
- YARP Overhead: 3ms
- Camunda Processing: 150ms
- Total: 1153ms
```

## Configuration Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                     Configuration Files                      │
└───────────────┬──────────────────────────────────────────────┘
                │
    ┌───────────┼───────────┬──────────────┐
    │           │           │              │
    ↓           ↓           ↓              ↓
┌─────────┐ ┌──────┐ ┌──────────┐ ┌──────────────┐
│ app     │ │ app  │ │ app      │ │ app          │
│ settings│ │ .Dev │ │ .Staging │ │ .Production  │
│ .json   │ │ .json│ │ .json    │ │ .json        │
└────┬────┘ └───┬──┘ └────┬─────┘ └──────┬───────┘
     │          │         │               │
     │      Environment-specific          │
     │      configurations                │
     │      override base                 │
     └──────────┴─────────┴───────────────┘
                │
                ↓
     ┌──────────────────────┐
     │  Runtime Config      │
     │  - ASPNETCORE_ENV    │
     │  - Merged settings   │
     └──────────┬───────────┘
                │
                ↓
     ┌──────────────────────┐
     │  Application         │
     │  - Reads config      │
     │  - Applies settings  │
     └──────────────────────┘
```

## Deployment

### Local Development Setup

```
┌──────────────────┐    ┌──────────────────┐
│  Camunda Run     │    │  YARP Proxy      │
│  (port 8080)     │←───│  (port 5000)     │
│  Native process  │    │  dotnet run      │
└──────────────────┘    └──────────────────┘
```

Both Camunda Run and the YARP proxy run as native processes on your machine.

**How to set up:**
1. Download and extract Camunda Run from https://camunda.com/download/
2. Start Camunda: `./start.sh` (Linux/Mac) or `start.bat` (Windows)
3. Start the proxy: `cd CamundaProxy && dotnet run`
4. Access via proxy: http://localhost:5000

## Extension Points

### 1. Add Per-Route Delays

```csharp
// Custom middleware with route-aware delays
public class RouteBasedDelayMiddleware
{
    private Dictionary<string, DelayOptions> _routeDelays;
    
    public async Task InvokeAsync(HttpContext context)
    {
        var path = context.Request.Path;
        var delay = GetDelayForPath(path);
        await Task.Delay(delay);
        await _next(context);
    }
}
```

### 2. Add Metrics Collection

```csharp
// Track request counts and timings
public class MetricsMiddleware
{
    private Counter _requestCount;
    private Histogram _requestDuration;
    
    public async Task InvokeAsync(HttpContext context)
    {
        _requestCount.Inc();
        var sw = Stopwatch.StartNew();
        await _next(context);
        _requestDuration.Observe(sw.Elapsed.TotalSeconds);
    }
}
```

### 3. Add Request/Response Logging

```csharp
// Log full request/response for debugging
public class RequestResponseLoggingMiddleware
{
    public async Task InvokeAsync(HttpContext context)
    {
        // Log request
        await LogRequest(context.Request);
        
        // Capture response
        var originalBody = context.Response.Body;
        using var newBody = new MemoryStream();
        context.Response.Body = newBody;
        
        await _next(context);
        
        // Log response
        await LogResponse(context.Response);
        
        newBody.Seek(0, SeekOrigin.Begin);
        await newBody.CopyToAsync(originalBody);
    }
}
```

## Security Considerations

### 1. Authentication Flow

```
Client → [Auth Middleware] → [Delay Middleware] → [YARP] → Camunda
           ↓
      Validate Token
      Check Permissions
```

### 2. Rate Limiting

```
Client → [Rate Limiter] → [Delay Middleware] → [YARP] → Camunda
           ↓
      Check Rate
      Enforce Limits
```

### 3. Request Validation

```
Client → [Validation] → [Delay Middleware] → [YARP] → Camunda
           ↓
      Validate Input
      Sanitize Data
```

## Monitoring & Observability

### Logging Levels

```
┌─────────────────────────────────────────┐
│ Log Level    │ Information              │
├─────────────────────────────────────────┤
│ Debug        │ Detailed YARP routing    │
│ Information  │ Delay values, requests   │
│ Warning      │ Slow responses, retries  │
│ Error        │ Failures, exceptions     │
│ Critical     │ System failures          │
└─────────────────────────────────────────┘
```

### Health Check Response

```json
{
  "status": "healthy",
  "timestamp": "2025-12-10T22:45:00.000Z",
  "delaySimulation": {
    "enabled": true,
    "useRandomDelay": false,
    "fixedDelayMs": 1000,
    "minDelayMs": 500,
    "maxDelayMs": 3000
  }
}
```

## Summary

This architecture provides:

✅ **Separation of Concerns**: Delay simulation separate from routing
✅ **Flexibility**: Easy configuration changes
✅ **Observability**: Built-in logging and health checks
✅ **Scalability**: Can handle high request volumes
✅ **Extensibility**: Easy to add new middleware
✅ **Production-Ready**: Based on Microsoft YARP

The design follows ASP.NET Core middleware patterns and YARP best practices, making it maintainable and performant.
