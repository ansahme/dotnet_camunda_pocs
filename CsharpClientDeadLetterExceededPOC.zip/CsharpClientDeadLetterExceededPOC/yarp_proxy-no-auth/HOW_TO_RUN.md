# How to Run This Project (No Docker Required!)

## Step 1: Install Camunda Run

Since we're not using Docker, you need to run Camunda Run natively.

### Download Camunda Run

1. Visit: https://camunda.com/download/
2. Download "Camunda Platform Run" (Community Edition)
3. Extract the ZIP file to a location of your choice

### Start Camunda Run

```bash
# On Linux/Mac
cd /path/to/camunda-run
./start.sh

# On Windows
cd C:\path\to\camunda-run
start.bat
```

Camunda will start on **http://localhost:8080**

You can verify it's running by visiting:
- http://localhost:8080/camunda/
- http://localhost:8080/engine-rest/version

## Step 2: Run the YARP Proxy

In a **new terminal window**:

```bash
# Navigate to the proxy project
cd /workspace/CamundaProxy

# Run the proxy (make sure .NET 10 is in PATH)
export PATH="$PATH:$HOME/.dotnet"
dotnet run
```

The proxy will start on **http://localhost:5000**

## Step 3: Test the Proxy

In a **third terminal window**:

```bash
# Test health check
curl http://localhost:5000/health

# Test proxying to Camunda (with delay)
curl http://localhost:5000/engine-rest/version

# Run automated tests
cd /workspace/CamundaProxy
./test-proxy.sh
```

## Expected Behavior

### Direct Camunda Access (No Delay)
```bash
$ time curl http://localhost:8080/engine-rest/version
{"version":"7.XX.X"}

real    0m0.150s  # Fast response
```

### Through Proxy (With Delay)
```bash
$ time curl http://localhost:5000/engine-rest/version
{"version":"7.XX.X"}

real    0m1.150s  # 1000ms delay + response time
```

## Configuration

Edit `CamundaProxy/appsettings.json` to change delay settings:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 1000
  }
}
```

Restart the proxy after configuration changes.

## Troubleshooting

### Problem: Camunda won't start

**Check Java version:**
```bash
java -version
# Camunda requires Java 11 or higher
```

**Check port 8080:**
```bash
# Linux/Mac
lsof -i :8080

# Windows
netstat -ano | findstr :8080
```

### Problem: Proxy won't start

**Check .NET version:**
```bash
dotnet --version
# Should show 10.0.xxx
```

**Check port 5000:**
```bash
# Linux/Mac
lsof -i :5000

# Windows
netstat -ano | findstr :5000
```

### Problem: Can't connect through proxy

1. Verify Camunda is running: `curl http://localhost:8080/engine-rest/version`
2. Verify proxy is running: `curl http://localhost:5000/health`
3. Check proxy logs for errors
4. Verify configuration in `appsettings.json`

## What You Should See

### Terminal 1: Camunda Run
```
  ____                                 _
 / ___|__ _ _ __ ___  _   _ _ __   __| | __ _
| |   / _` | '_ ` _ \| | | | '_ \ / _` |/ _` |
| |__| (_| | | | | | | |_| | | | | (_| | (_| |
 \____\__,_|_| |_| |_|\__,_|_| |_|\__,_|\__,_|

Starting Camunda Platform Run...
Camunda Platform Run started on port 8080
```

### Terminal 2: YARP Proxy
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5000
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to shut down.
```

### Terminal 3: Test Output
```
info: CamundaProxy.DelaySimulationMiddleware[0]
      Simulating network delay of 1000ms for request GET /engine-rest/version
```

## Summary

✅ **No Docker needed** - Everything runs natively
✅ **Two processes** - Camunda Run + YARP Proxy
✅ **Simple setup** - Download, extract, run
✅ **Easy testing** - Curl or browser
✅ **Configurable** - JSON configuration
✅ **Portable** - Works on Linux, Mac, Windows

## Architecture

```
┌─────────────────┐
│   Your Client   │
└────────┬────────┘
         │
         ↓ http://localhost:5000
┌─────────────────┐
│   YARP Proxy    │  ← You run this with dotnet run
│  (with delays)  │
└────────┬────────┘
         │
         ↓ http://localhost:8080
┌─────────────────┐
│  Camunda Run    │  ← You run this with start.sh/start.bat
└─────────────────┘
```

Both processes run natively on your machine. No containers, no Docker, no complexity!

## Next Steps

- Read `QUICKSTART.md` for minimal instructions
- Read `SETUP_GUIDE.md` for comprehensive guide
- Read `ARCHITECTURE.md` for technical details
- Experiment with different delay configurations
- Integrate with your own applications

**Happy Testing!** 🚀
