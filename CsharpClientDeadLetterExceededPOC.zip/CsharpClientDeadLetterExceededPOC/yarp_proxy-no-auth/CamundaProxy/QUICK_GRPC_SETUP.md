# Quick gRPC Setup (3 Steps)

## For gRPC on localhost:26500

### Step 1: Use gRPC Configuration

```bash
cd /workspace/CamundaProxy
cp appsettings.grpc.json appsettings.json
```

This configures the proxy to forward to `localhost:26500` using HTTP/2.

### Step 2: Run the Proxy

```bash
export PATH="$PATH:$HOME/.dotnet"
dotnet run
```

### Step 3: Test with grpcurl

```bash
# Through proxy (with delay simulation)
grpcurl -plaintext localhost:5000 list

# Direct to server (no delay)
grpcurl -plaintext localhost:26500 list
```

## What's Different for gRPC?

The configuration uses HTTP/2 (required for gRPC):

```json
{
  "ReverseProxy": {
    "Clusters": {
      "grpc-cluster": {
        "Destinations": {
          "grpc-instance": {
            "Address": "http://localhost:26500"
          }
        },
        "HttpRequest": {
          "Version": "2.0",
          "VersionPolicy": "RequestVersionOrHigher"
        }
      }
    }
  }
}
```

## Configuration Files

- `appsettings.json` - HTTP/REST (Camunda on port 8080)
- `appsettings.grpc.json` - gRPC only (port 26500)  ← Use this!
- `appsettings.multi.json` - Both HTTP and gRPC

## Delay Simulation Works with gRPC!

Edit the `DelaySimulation` section in your config:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 500
  }
}
```

The delay is applied before forwarding gRPC requests.

## Need More Details?

See `GRPC_GUIDE.md` for:
- Complete gRPC documentation
- Client examples (C#, Python, Go)
- Streaming RPC support
- Load balancing
- Troubleshooting
- Advanced configurations

## Quick Comparison

| What | Port | How to Test |
|------|------|-------------|
| HTTP/REST (Camunda) | 8080 → 5000 | `curl localhost:5000/api` |
| gRPC Service | 26500 → 5000 | `grpcurl -plaintext localhost:5000 list` |
| Health Check | 5000 | `curl localhost:5000/health` |

All traffic goes through the proxy at port 5000 with delay simulation!
