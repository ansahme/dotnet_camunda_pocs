# gRPC Support Guide

## Overview

This YARP proxy **fully supports gRPC** (Google Remote Procedure Call) protocol. Since gRPC uses HTTP/2, YARP can proxy gRPC requests just like HTTP/REST requests, with the same delay simulation capabilities.

## Quick Start - gRPC Only

### 1. Update Configuration

Use the gRPC-specific configuration:

```bash
cd /workspace/CamundaProxy

# Copy gRPC config to appsettings.json
cp appsettings.grpc.json appsettings.json

# Or specify it when running
dotnet run --environment grpc
```

### 2. Run the Proxy

```bash
export PATH="$PATH:$HOME/.dotnet"
dotnet run
```

The proxy will forward all requests to `http://localhost:26500` using HTTP/2.

### 3. Test with grpcurl

```bash
# Install grpcurl if needed
# go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest

# Test through proxy (with delay)
grpcurl -plaintext localhost:5000 list

# Compare with direct connection (no delay)
grpcurl -plaintext localhost:26500 list
```

## Configuration Files

### Option 1: gRPC Only (`appsettings.grpc.json`)

Forward all traffic to a gRPC service on port 26500:

```json
{
  "ReverseProxy": {
    "Routes": {
      "grpc-route": {
        "ClusterId": "grpc-cluster",
        "Match": {
          "Path": "{**catch-all}"
        }
      }
    },
    "Clusters": {
      "grpc-cluster": {
        "Destinations": {
          "grpc-instance": {
            "Address": "http://localhost:26500"
          }
        },
        "HttpRequest": {
          "Version": "2.0",
          "VersionPolicy": "RequestVersionOrHigher"
        }
      }
    }
  }
}
```

**Key settings for gRPC:**
- `Version`: "2.0" - Forces HTTP/2 (required for gRPC)
- `VersionPolicy`: "RequestVersionOrHigher" - Allows version negotiation

### Option 2: Both HTTP and gRPC (`appsettings.multi.json`)

Support both HTTP/REST (Camunda on 8080) and gRPC (on 26500) simultaneously:

```json
{
  "ReverseProxy": {
    "Routes": {
      "grpc-route": {
        "ClusterId": "grpc-cluster",
        "Match": {
          "Path": "/grpc/{**catch-all}",
          "Headers": [
            {
              "Name": "content-type",
              "Values": ["application/grpc"],
              "Mode": "ExactHeader"
            }
          ]
        },
        "Transforms": [
          { "PathRemovePrefix": "/grpc" }
        ]
      },
      "http-route": {
        "ClusterId": "http-cluster",
        "Match": {
          "Path": "/http/{**catch-all}"
        },
        "Transforms": [
          { "PathRemovePrefix": "/http" }
        ]
      }
    },
    "Clusters": {
      "grpc-cluster": {
        "Destinations": {
          "grpc-instance": {
            "Address": "http://localhost:26500"
          }
        },
        "HttpRequest": {
          "Version": "2.0",
          "VersionPolicy": "RequestVersionOrHigher"
        }
      },
      "http-cluster": {
        "Destinations": {
          "http-instance": {
            "Address": "http://localhost:8080"
          }
        }
      }
    }
  }
}
```

**Usage:**
- gRPC requests: `localhost:5000/grpc/YourService/Method`
- HTTP requests: `localhost:5000/http/api/endpoint`
- Default: Routes to HTTP cluster

## HTTP/2 Configuration

The proxy is configured to support both HTTP/1.1 and HTTP/2:

```csharp
builder.WebHost.ConfigureKestrel(options =>
{
    // Supports both HTTP/1.1 (REST) and HTTP/2 (gRPC)
    options.ListenLocalhost(5000, o => 
        o.Protocols = HttpProtocols.Http1AndHttp2);
});
```

## Delay Simulation with gRPC

The delay simulation middleware works identically for gRPC and HTTP:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 500
  }
}
```

**Request flow:**
1. gRPC client → Proxy (port 5000)
2. Delay middleware applies delay
3. Proxy forwards via HTTP/2 → gRPC server (port 26500)
4. Response returns through proxy

## Testing gRPC Through the Proxy

### Using grpcurl

```bash
# List services through proxy (with delay)
grpcurl -plaintext localhost:5000 list

# Describe a service
grpcurl -plaintext localhost:5000 describe YourService

# Call a method
grpcurl -plaintext -d '{"name": "test"}' \
  localhost:5000 YourService/YourMethod

# With metadata
grpcurl -plaintext \
  -H "Authorization: Bearer token" \
  localhost:5000 list
```

### Using a gRPC Client

**C# Example:**
```csharp
// Create channel pointing to proxy
var channel = GrpcChannel.ForAddress("http://localhost:5000");

// Use your gRPC client
var client = new YourService.YourServiceClient(channel);

// Make calls (will go through proxy with delay)
var response = await client.YourMethodAsync(new Request());
```

**Python Example:**
```python
import grpc
from your_proto import your_service_pb2_grpc

# Connect to proxy
channel = grpc.insecure_channel('localhost:5000')
stub = your_service_pb2_grpc.YourServiceStub(channel)

# Make call (will go through proxy with delay)
response = stub.YourMethod(request)
```

**Go Example:**
```go
// Connect to proxy
conn, err := grpc.Dial("localhost:5000", grpc.WithInsecure())
defer conn.Close()

client := pb.NewYourServiceClient(conn)

// Make call (will go through proxy with delay)
response, err := client.YourMethod(context.Background(), request)
```

## Common Use Cases

### 1. Test gRPC Client Timeout Handling

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 5000
  }
}
```

Configure your client timeout to 3000ms and test how it handles the timeout.

### 2. Simulate Network Latency

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 50,
    "MaxDelayMs": 300
  }
}
```

Adds realistic network latency to gRPC calls.

### 3. Test Streaming RPCs Under Delay

The delay is applied to the initial request, not to each streamed message:

```bash
# Server streaming - delay on initial request only
grpcurl -plaintext localhost:5000 \
  YourService/ServerStreamingMethod

# Bidirectional streaming - delay on connection establishment
grpcurl -plaintext localhost:5000 \
  YourService/BidiStreamingMethod
```

### 4. Load Testing gRPC Services

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 100,
    "MaxDelayMs": 500
  }
}
```

Run load tests through the proxy to include realistic delays.

## Limitations and Considerations

### 1. Delay Application

The delay middleware applies to:
- ✅ Initial gRPC connection/request
- ❌ Individual streamed messages

For streaming RPCs, only the initial delay is applied, not per message.

### 2. HTTP/2 Requirements

gRPC requires HTTP/2:
- ✅ Supported: `http://` with HTTP/2 (plaintext)
- ✅ Supported: `https://` with HTTP/2 (TLS)
- ❌ Not supported: HTTP/1.1 for gRPC

### 3. TLS/SSL

For secure gRPC (over TLS):

```csharp
// In Program.cs
options.ListenLocalhost(5001, o => 
{
    o.Protocols = HttpProtocols.Http2;
    o.UseHttps();
});
```

Update destination:
```json
{
  "Address": "https://localhost:26500"
}
```

### 4. Load Balancing

YARP supports load balancing for gRPC:

```json
{
  "Clusters": {
    "grpc-cluster": {
      "LoadBalancingPolicy": "RoundRobin",
      "Destinations": {
        "grpc-1": { "Address": "http://localhost:26500" },
        "grpc-2": { "Address": "http://localhost:26501" },
        "grpc-3": { "Address": "http://localhost:26502" }
      },
      "HttpRequest": {
        "Version": "2.0"
      }
    }
  }
}
```

## Health Check

The health check endpoint shows current configuration:

```bash
curl http://localhost:5000/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2025-12-10T...",
  "delaySimulation": {
    "enabled": true,
    "useRandomDelay": false,
    "fixedDelayMs": 500,
    "minDelayMs": 200,
    "maxDelayMs": 2000
  }
}
```

Note: The health check itself uses HTTP/1.1 and is not proxied.

## Troubleshooting

### Problem: Connection refused

**Check gRPC server:**
```bash
grpcurl -plaintext localhost:26500 list
```

If this fails, your gRPC server isn't running on port 26500.

### Problem: "protocol error"

This usually means HTTP/1.1 is being used instead of HTTP/2.

**Solution:** Ensure `HttpRequest.Version` is set to "2.0" in cluster configuration.

### Problem: Streaming doesn't work

YARP fully supports gRPC streaming. Check:
1. HTTP/2 is enabled in Kestrel
2. Client is using HTTP/2
3. Server supports streaming

### Problem: Delays not applied to stream messages

This is expected. Delays apply to connection/request, not individual messages.

## Advanced: Per-Service Delay Configuration

You can configure different delays for different gRPC services:

```json
{
  "ReverseProxy": {
    "Routes": {
      "slow-service-route": {
        "ClusterId": "slow-grpc-cluster",
        "Match": {
          "Path": "/SlowService/{**catch-all}"
        }
      },
      "fast-service-route": {
        "ClusterId": "fast-grpc-cluster",
        "Match": {
          "Path": "/FastService/{**catch-all}"
        }
      }
    }
  }
}
```

Then use custom middleware to apply different delays per route.

## Example: Full Setup

### 1. Start gRPC Server

```bash
# Your gRPC server on port 26500
./your-grpc-server --port 26500
```

### 2. Configure Proxy for gRPC

```bash
cd /workspace/CamundaProxy
cp appsettings.grpc.json appsettings.json
```

### 3. Run Proxy

```bash
export PATH="$PATH:$HOME/.dotnet"
dotnet run
```

### 4. Test

```bash
# Direct (no delay)
time grpcurl -plaintext localhost:26500 list

# Through proxy (with delay)
time grpcurl -plaintext localhost:5000 list
```

You should see the delay difference!

## Comparison: HTTP/REST vs gRPC

| Feature | HTTP/REST | gRPC |
|---------|-----------|------|
| Protocol | HTTP/1.1 | HTTP/2 |
| Port | 8080 | 26500 |
| Content-Type | application/json | application/grpc |
| Config File | appsettings.json | appsettings.grpc.json |
| Testing Tool | curl | grpcurl |
| Streaming | Limited | Full support |
| Performance | Good | Excellent |

## Summary

✅ **YARP fully supports gRPC**
✅ **Delay simulation works with gRPC**
✅ **HTTP/2 enabled by default**
✅ **Easy configuration**
✅ **Supports streaming**
✅ **Load balancing supported**

The proxy seamlessly handles gRPC with the same delay simulation capabilities as HTTP/REST!

## Resources

- [YARP gRPC Documentation](https://microsoft.github.io/reverse-proxy/articles/grpc.html)
- [gRPC Official Site](https://grpc.io/)
- [grpcurl Tool](https://github.com/fullstorydev/grpcurl)
- [HTTP/2 Specification](https://http2.github.io/)
