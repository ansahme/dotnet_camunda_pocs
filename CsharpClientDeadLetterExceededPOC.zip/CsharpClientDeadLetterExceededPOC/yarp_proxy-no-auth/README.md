# YARP Reverse Proxy with Network Delay Simulation for Camunda

This repository contains a .NET 10 YARP-based reverse proxy that forwards requests to Camunda Run with configurable network delay simulation capabilities.

## Project Overview

The `CamundaProxy` project demonstrates how to:
- Set up a reverse proxy using Microsoft YARP (Yet Another Reverse Proxy)
- Implement custom middleware for simulating network delays
- Configure routing to forward requests to Camunda Run
- Test application behavior under various network conditions

## Quick Start

### Prerequisites

- .NET 10 SDK
- Camunda Run running on `http://localhost:8080`
  - Download from: https://camunda.com/download/
  - Extract and run: `./start.sh` (Linux/Mac) or `start.bat` (Windows)

### Build and Run

```bash
cd CamundaProxy
dotnet restore
dotnet build
dotnet run
```

The proxy will be available at:
- HTTP: `http://localhost:5000`
- HTTPS: `https://localhost:5001`

### Test the Proxy

```bash
# Health check
curl http://localhost:5000/health

# Access Camunda through the proxy
curl http://localhost:5000/engine-rest/version
```

## Features

### 1. Network Delay Simulation

Simulate various network conditions:

- **Fixed delays**: Constant latency for predictable testing
- **Random delays**: Variable latency for realistic scenarios
- **Configurable ranges**: Customize min/max delay values
- **Enable/disable**: Toggle delays without code changes

### 2. Flexible Configuration

All settings are managed through `appsettings.json`:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 500,
    "MaxDelayMs": 3000
  }
}
```

### 3. Health Monitoring

Built-in health check endpoint shows:
- Proxy status
- Current delay configuration
- Timestamp

### 4. Production Ready

- Based on Microsoft YARP
- .NET 10 performance
- Comprehensive logging
- Easy deployment

## Use Cases

1. **Resilience Testing**: Test how applications handle slow responses
2. **Load Testing**: Add realistic latency to load tests
3. **Timeout Testing**: Verify timeout handling with long delays
4. **Development**: Simulate production network conditions locally
5. **Integration Testing**: Test distributed system behavior

## Project Structure

```
/
├── CamundaProxy/                   # Main proxy application
│   ├── Program.cs                  # Application entry point
│   ├── DelaySimulationMiddleware.cs # Delay simulation logic
│   ├── appsettings.json            # Production configuration
│   ├── appsettings.Development.json # Development configuration
│   ├── appsettings.Examples.json   # Example configurations
│   └── README.md                   # Detailed documentation
└── README.md                       # This file
```

## Documentation

For detailed documentation, see [CamundaProxy/README.md](CamundaProxy/README.md)

## Technology Stack

- **.NET 10**: Latest .NET platform
- **YARP**: Microsoft's reverse proxy library (with full gRPC support)
- **ASP.NET Core**: Web framework with HTTP/2
- **C# 13**: Modern C# features
- **Kestrel**: High-performance HTTP/1.1 and HTTP/2 server

## Configuration Examples

### Scenario 1: No Delay (Production)

```json
{
  "DelaySimulation": {
    "Enabled": false
  }
}
```

### Scenario 2: Fixed 1-Second Delay

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 1000
  }
}
```

### Scenario 3: Random 500-3000ms Delay

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 500,
    "MaxDelayMs": 3000
  }
}
```

## Contributing

This is a demonstration project. Feel free to extend it with additional features such as:
- Per-route delay configurations
- Response time metrics
- Request/response logging
- Circuit breaker patterns
- Rate limiting

## Resources

- [YARP Documentation](https://microsoft.github.io/reverse-proxy/)
- [Camunda Platform Documentation](https://docs.camunda.io/)
- [.NET 10 Documentation](https://learn.microsoft.com/dotnet/core/whats-new/dotnet-10/overview)
- [ASP.NET Core Middleware](https://learn.microsoft.com/aspnet/core/fundamentals/middleware/)

## License

This project is provided as-is for demonstration purposes.
