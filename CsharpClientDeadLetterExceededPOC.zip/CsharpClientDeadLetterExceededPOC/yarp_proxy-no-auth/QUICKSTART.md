# Quick Start Guide

## Prerequisites
- .NET 10 SDK installed
- Camunda Run running on port 8080 (download from https://camunda.com/download/)

## Run in 3 Steps

```bash
# 1. Go to project directory
cd /workspace/CamundaProxy

# 2. Run the proxy
export PATH="$PATH:$HOME/.dotnet"
dotnet run

# 3. Test it (in another terminal)
curl http://localhost:5000/health
```

## Test with Camunda

```bash
# Direct to Camunda (no delay)
curl http://localhost:8080/engine-rest/version

# Through proxy (with delay)
curl http://localhost:5000/engine-rest/version
```

## Change Delay Settings

Edit `appsettings.json`:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 2000
  }
}
```

Restart the proxy to apply changes.

## Common Configurations

**No delay:**
```json
{ "DelaySimulation": { "Enabled": false } }
```

**Fixed 1-second delay:**
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 1000
  }
}
```

**Random 500-3000ms delay:**
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 500,
    "MaxDelayMs": 3000
  }
}
```

## Need More Help?

- Full documentation: `CamundaProxy/README.md`
- Detailed setup: `SETUP_GUIDE.md`
- Project overview: `README.md`
