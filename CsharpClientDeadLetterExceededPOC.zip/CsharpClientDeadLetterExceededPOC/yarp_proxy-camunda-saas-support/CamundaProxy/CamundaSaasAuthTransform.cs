using Yarp.ReverseProxy.Transforms;
using Yarp.ReverseProxy.Transforms.Builder;

namespace CamundaProxy;

/// <summary>
/// YARP transform that adds OAuth2 authentication to requests going to Camunda SaaS
/// </summary>
public class CamundaSaasAuthTransform : ITransformProvider
{
    private readonly CamundaSaasAuthService _authService;
    private readonly ILogger<CamundaSaasAuthTransform> _logger;

    public CamundaSaasAuthTransform(
        CamundaSaasAuthService authService,
        ILogger<CamundaSaasAuthTransform> logger)
    {
        _authService = authService;
        _logger = logger;
    }

    public void ValidateRoute(TransformRouteValidationContext context)
    {
        // No validation needed
    }

    public void ValidateCluster(TransformClusterValidationContext context)
    {
        // No validation needed
    }

    public void Apply(TransformBuilderContext context)
    {
        // Add transform to all routes
        context.AddRequestTransform(async transformContext =>
        {
            try
            {
                // Get access token (cached or new)
                var token = await _authService.GetAccessTokenAsync(
                    transformContext.HttpContext.RequestAborted);

                // Add Authorization header
                transformContext.ProxyRequest.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                _logger.LogDebug("Added OAuth2 Bearer token to request {Method} {Path}",
                    transformContext.HttpContext.Request.Method,
                    transformContext.HttpContext.Request.Path);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to add authentication to request");
                throw;
            }
        });
    }
}
