using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace CamundaProxy;

/// <summary>
/// Service for authenticating with Camunda SaaS using OAuth2 client credentials flow
/// Note: No caching - requests new token for each call (suitable for local testing)
/// </summary>
public class CamundaSaasAuthService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<CamundaSaasAuthService> _logger;
    private readonly CamundaSaasConfig _config;

    public CamundaSaasAuthService(
        HttpClient httpClient,
        ILogger<CamundaSaasAuthService> logger,
        IConfiguration configuration)
    {
        _httpClient = httpClient;
        _logger = logger;
        _config = configuration.GetSection("CamundaSaas").Get<CamundaSaasConfig>() 
                  ?? throw new InvalidOperationException("CamundaSaas configuration not found");
    }

    /// <summary>
    /// Gets a fresh access token (no caching for local testing)
    /// </summary>
    public async Task<string> GetAccessTokenAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Requesting OAuth2 token from {TokenUrl}", _config.TokenUrl);

        var content = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("client_id", _config.ClientId),
            new KeyValuePair<string, string>("client_secret", _config.ClientSecret),
            new KeyValuePair<string, string>("audience", _config.Audience),
            new KeyValuePair<string, string>("grant_type", "client_credentials")
        });

        try
        {
            var response = await _httpClient.PostAsync(_config.TokenUrl, content, cancellationToken);
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
            var tokenResponse = JsonSerializer.Deserialize<OAuth2TokenResponse>(responseBody)
                ?? throw new InvalidOperationException("Failed to deserialize token response");

            _logger.LogInformation("✅ Successfully obtained OAuth2 token (expires in {Seconds}s)", 
                tokenResponse.ExpiresIn);

            return tokenResponse.AccessToken;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "❌ Failed to obtain OAuth2 token from {TokenUrl}", _config.TokenUrl);
            throw new InvalidOperationException("Failed to authenticate with Camunda SaaS", ex);
        }
    }
}

/// <summary>
/// Configuration for Camunda SaaS authentication
/// </summary>
public class CamundaSaasConfig
{
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string TokenUrl { get; set; } = string.Empty;
    public string Audience { get; set; } = string.Empty;
    public string ZeebeAddress { get; set; } = string.Empty;
}

/// <summary>
/// OAuth2 token request
/// </summary>
internal class OAuth2TokenRequest
{
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string Audience { get; set; } = string.Empty;
    public string GrantType { get; set; } = "client_credentials";
}

/// <summary>
/// OAuth2 token response from Camunda SaaS
/// </summary>
internal class OAuth2TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;

    [JsonPropertyName("token_type")]
    public string TokenType { get; set; } = "Bearer";

    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; set; }

    [JsonPropertyName("scope")]
    public string? Scope { get; set; }
}
