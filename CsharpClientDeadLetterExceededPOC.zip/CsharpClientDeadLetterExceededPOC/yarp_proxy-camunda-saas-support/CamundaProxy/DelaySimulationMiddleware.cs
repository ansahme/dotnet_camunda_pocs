namespace CamundaProxy;

/// <summary>
/// Middleware that simulates network delays for testing and development purposes
/// </summary>
public class DelaySimulationMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<DelaySimulationMiddleware> _logger;
    private readonly DelaySimulationOptions _options;

    public DelaySimulationMiddleware(
        RequestDelegate next,
        ILogger<DelaySimulationMiddleware> logger,
        DelaySimulationOptions options)
    {
        _next = next;
        _logger = logger;
        _options = options;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (_options.Enabled)
        {
            _logger.LogInformation("Use random delay is enabled: {}", _options.UseRandomDelay);
            var delay = _options.UseRandomDelay
                ? Random.Shared.Next(_options.MinDelayMs, _options.MaxDelayMs)
                : _options.FixedDelayMs;

            _logger.LogInformation(
                "Simulating network delay of {DelayMs}ms for request {Method} {Path}",
                delay,
                context.Request.Method,
                context.Request.Path);

            await Task.Delay(delay);
        }

        await _next(context);
    }
}

/// <summary>
/// Configuration options for delay simulation
/// </summary>
public class DelaySimulationOptions
{
    /// <summary>
    /// Enable or disable delay simulation
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Use random delays between MinDelayMs and MaxDelayMs
    /// </summary>
    public bool UseRandomDelay { get; set; } = false;

    /// <summary>
    /// Fixed delay in milliseconds (used when UseRandomDelay is false)
    /// </summary>
    public int FixedDelayMs { get; set; } = 10000;

    /// <summary>
    /// Minimum delay in milliseconds (used when UseRandomDelay is true)
    /// </summary>
    public int MinDelayMs { get; set; } = 500;

    /// <summary>
    /// Maximum delay in milliseconds (used when UseRandomDelay is true)
    /// </summary>
    public int MaxDelayMs { get; set; } = 3000;
}

/// <summary>
/// Extension methods for registering the delay simulation middleware
/// </summary>
public static class DelaySimulationExtensions
{
    public static IApplicationBuilder UseDelaySimulation(
        this IApplicationBuilder app,
        Action<DelaySimulationOptions>? configure = null)
    {
        var options = new DelaySimulationOptions();
        configure?.Invoke(options);

        return app.UseMiddleware<DelaySimulationMiddleware>(options);
    }
}
