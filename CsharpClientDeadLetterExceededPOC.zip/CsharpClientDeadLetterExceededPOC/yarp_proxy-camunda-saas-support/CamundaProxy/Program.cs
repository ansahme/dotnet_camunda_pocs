using CamundaProxy;
using Microsoft.AspNetCore.Server.Kestrel.Core;

var builder = WebApplication.CreateBuilder(args);

// Configure Kestrel to support HTTP/2 (required for gRPC)
builder.WebHost.ConfigureKestrel(options =>
{
    // HTTPS endpoint with HTTP/1.1 and HTTP/2 (ALPN negotiation)
    // This enables HTTP/2 via TLS and works with gRPC
    options.ListenLocalhost(5001, listenOptions =>
    {
        listenOptions.Protocols = HttpProtocols.Http1AndHttp2;
        listenOptions.UseHttps(); // Uses development certificate
    });
    
    // Optional: Plain HTTP endpoint (HTTP/1.1 only) for health checks
    options.ListenLocalhost(5000, listenOptions =>
    {
        listenOptions.Protocols = HttpProtocols.Http1;
    });
});

// Check if Camunda SaaS configuration exists
var saasConfig = builder.Configuration.GetSection("CamundaSaas");
var isSaasMode = saasConfig.Exists() && !string.IsNullOrEmpty(saasConfig["ClientId"]);

if (isSaasMode)
{
    // Register HTTP client for OAuth2 token requests
    builder.Services.AddHttpClient<CamundaSaasAuthService>();
    
    // Register the auth service
    builder.Services.AddSingleton<CamundaSaasAuthService>();
    
    // Add YARP with custom transform for authentication
    builder.Services.AddReverseProxy()
        .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"))
        .AddTransforms<CamundaSaasAuthTransform>();
    
    Console.WriteLine("✅ Camunda SaaS mode enabled with OAuth2 authentication");
}
else
{
    // Standard YARP configuration (local/on-premise)
    builder.Services.AddReverseProxy()
        .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));
    
    Console.WriteLine("ℹ️  Local/on-premise mode (no OAuth2 authentication)");
}

// Add logging
builder.Logging.AddConsole();

var app = builder.Build();

// Configure delay simulation based on appsettings.json
var delayConfig = builder.Configuration.GetSection("DelaySimulation");
var delayEnabled = delayConfig.GetValue<bool>("Enabled", true);
var useRandomDelay = delayConfig.GetValue<bool>("UseRandomDelay", false);
var fixedDelayMs = delayConfig.GetValue<int>("FixedDelayMs", 1000);
var minDelayMs = delayConfig.GetValue<int>("MinDelayMs", 500);
var maxDelayMs = delayConfig.GetValue<int>("MaxDelayMs", 3000);

// Add delay simulation middleware before proxying
app.UseDelaySimulation(options =>
{
    options.Enabled = delayEnabled;
    options.UseRandomDelay = false; //hard coding false for now
    options.FixedDelayMs = fixedDelayMs;
    options.MinDelayMs = minDelayMs;
    options.MaxDelayMs = maxDelayMs;
});

// Map reverse proxy routes
app.MapReverseProxy();

// Health check endpoint
app.MapGet("/health", (IConfiguration config) =>
{
    var saasConfigSection = config.GetSection("CamundaSaas");
    var isSaas = saasConfigSection.Exists() && !string.IsNullOrEmpty(saasConfigSection["ClientId"]);
    
    return Results.Ok(new
    {
        status = "healthy",
        timestamp = DateTime.UtcNow,
        mode = isSaas ? "Camunda SaaS" : "Local/On-Premise",
        authentication = isSaas ? "OAuth2" : "None",
        delaySimulation = new
        {
            enabled = delayEnabled,
            useRandomDelay = useRandomDelay,
            fixedDelayMs = fixedDelayMs,
            minDelayMs = minDelayMs,
            maxDelayMs = maxDelayMs
        }
    });
});

app.Run();
