# Delay Configuration Guide

## ✅ Delays Are Already Working!

The proxy already has network delay simulation **built-in and active**. Every request is being delayed before forwarding to Zeebe Gateway.

## Current Configuration

Your `appsettings.json` currently has:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 500,
    "MinDelayMs": 200,
    "MaxDelayMs": 2000
  }
}
```

**What this means:**
- ✅ Delays are **enabled**
- ✅ Using **fixed 500ms delay** on every request
- ✅ You should see delay logs in the proxy output

## How to Verify Delays Are Working

### 1. Check Proxy Logs

When your job worker makes requests, you should see:

```
info: CamundaProxy.DelaySimulationMiddleware[0]
      Simulating network delay of 500ms for request POST /gateway_protocol.Gateway/ActivateJobs
```

### 2. Compare Response Times

**Direct to Zeebe (no delay):**
```bash
time grpcurl -plaintext localhost:26500 gateway.Gateway/Topology
# Real time: ~0.050s
```

**Through Proxy (with 500ms delay):**
```bash
time grpcurl -insecure localhost:5001 gateway.Gateway/Topology
# Real time: ~0.550s (500ms delay + processing)
```

**Difference = Your configured delay!**

### 3. Check Health Endpoint

```bash
curl http://localhost:5000/health
```

Response shows current delay configuration:
```json
{
  "status": "healthy",
  "timestamp": "...",
  "delaySimulation": {
    "enabled": true,
    "useRandomDelay": false,
    "fixedDelayMs": 500,
    "minDelayMs": 200,
    "maxDelayMs": 2000
  }
}
```

## Delay Configuration Options

### Option 1: Fixed Delay (Consistent)

**Use when:** You want predictable, consistent delays

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 1000
  }
}
```

**Result:** Every request has exactly 1000ms delay

**Good for:**
- Consistent testing
- Measuring specific timeout thresholds
- Predictable performance testing

### Option 2: Random Delay (Realistic)

**Use when:** You want to simulate real-world network variability

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 100,
    "MaxDelayMs": 2000
  }
}
```

**Result:** Each request has a random delay between 100ms and 2000ms

**Good for:**
- Realistic network simulation
- Testing application resilience
- Load testing with variability

### Option 3: No Delay (Baseline)

**Use when:** You want to measure performance without delays

```json
{
  "DelaySimulation": {
    "Enabled": false
  }
}
```

**Result:** No delays, maximum performance

**Good for:**
- Baseline performance measurement
- Production-like testing
- Comparing with/without delays

## Common Delay Scenarios

### Scenario 1: Local Network (Fast)

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 10,
    "MaxDelayMs": 50
  }
}
```

**Simulates:** Fast local network with minimal jitter  
**Average delay:** ~30ms

### Scenario 2: Good Internet Connection

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 50,
    "MaxDelayMs": 200
  }
}
```

**Simulates:** Typical good internet connection  
**Average delay:** ~125ms

### Scenario 3: Slow Internet Connection

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 200,
    "MaxDelayMs": 1000
  }
}
```

**Simulates:** Slow or congested internet  
**Average delay:** ~600ms

### Scenario 4: Poor Network Quality

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 500,
    "MaxDelayMs": 3000
  }
}
```

**Simulates:** High-latency or unreliable network  
**Average delay:** ~1750ms

### Scenario 5: Network Spikes

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 50,
    "MaxDelayMs": 5000
  }
}
```

**Simulates:** Generally fast with occasional severe delays  
**Average delay:** ~2525ms (but mostly fast with spikes)

### Scenario 6: Timeout Testing

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 15000
  }
}
```

**Simulates:** Delays longer than typical timeouts  
**Purpose:** Test timeout handling and error messages

### Scenario 7: Gradual Degradation

Start with low delays and increase over time to test degradation:

**Phase 1:**
```json
{ "FixedDelayMs": 100 }
```

**Phase 2:**
```json
{ "FixedDelayMs": 500 }
```

**Phase 3:**
```json
{ "FixedDelayMs": 2000 }
```

**Phase 4:**
```json
{ "FixedDelayMs": 5000 }
```

## How to Change Delays

### Method 1: Edit appsettings.json

1. Edit `/workspace/CamundaProxy/appsettings.json`
2. Change the `DelaySimulation` section
3. Restart the proxy: `dotnet run`

### Method 2: Use Different Environment

**Create custom configuration file:**

`appsettings.SlowNetwork.json`:
```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 1000,
    "MaxDelayMs": 3000
  }
}
```

**Run with custom environment:**
```bash
dotnet run --environment SlowNetwork
```

### Method 3: Command Line Override (Future Enhancement)

Could add support for command-line delay configuration:
```bash
dotnet run --DelaySimulation:FixedDelayMs=2000
```

## Testing Different Delay Scenarios

### Test Script

Create `test-delays.sh`:

```bash
#!/bin/bash

echo "Testing different delay configurations..."

# Test 1: No delay
echo "1. Testing with no delay..."
sed -i 's/"Enabled": true/"Enabled": false/' appsettings.json
dotnet run &
PID=$!
sleep 5
time grpcurl -insecure localhost:5001 gateway.Gateway/Topology
kill $PID

# Test 2: Fixed 500ms delay
echo "2. Testing with 500ms fixed delay..."
# Update config...
# Restart and test...

# Test 3: Random delays
echo "3. Testing with random delays (100-1000ms)..."
# Update config...
# Restart and test...
```

### Measurement Tools

**1. Time Command:**
```bash
time grpcurl -insecure localhost:5001 gateway.Gateway/Topology
```

**2. Custom Client Timing:**
```csharp
var stopwatch = Stopwatch.StartNew();
var response = await client.SomeMethodAsync(request);
stopwatch.Stop();
_logger.LogInformation("Request took {ElapsedMs}ms", stopwatch.ElapsedMilliseconds);
```

**3. Monitor Proxy Logs:**
```
grep "Simulating network delay" proxy.log
```

## Delay + Timeout Configuration

Ensure your client timeout is greater than maximum delay:

**Formula:**
```
Client Timeout > Max Delay + Backend Processing Time + Safety Margin
```

**Example:**
```json
// Proxy
"MaxDelayMs": 2000

// Client
"TimeoutInMilliseconds": 10000  // 2000 + processing + margin
```

**If timeout is too short:**
```
Client Timeout: 5000ms
Max Delay: 3000ms
Backend Processing: 1000ms
Total: 4000ms (OK)

But if Backend Processing spikes to 3000ms:
Total: 6000ms (Timeout!)
```

## Advanced: Per-Route Delays (Future Enhancement)

Currently, delays apply to all requests. You could extend the middleware to support per-route delays:

```json
{
  "DelaySimulation": {
    "Routes": {
      "/gateway_protocol.Gateway/ActivateJobs": {
        "FixedDelayMs": 100
      },
      "/gateway_protocol.Gateway/CompleteJob": {
        "FixedDelayMs": 500
      },
      "default": {
        "UseRandomDelay": true,
        "MinDelayMs": 200,
        "MaxDelayMs": 1000
      }
    }
  }
}
```

**Implementation would require:**
1. Modify `DelaySimulationMiddleware.cs` to read path
2. Match path against configuration
3. Apply path-specific delay

## Monitoring Delays

### View Delay Statistics

Create a script to analyze delay patterns:

```bash
# Extract delays from logs
grep "Simulating network delay" proxy.log | \
  awk '{print $NF}' | \
  sed 's/ms//' | \
  awk '{sum+=$1; count++} END {print "Average:", sum/count "ms"}'
```

### Real-Time Monitoring

```bash
# Watch delays in real-time
tail -f proxy.log | grep "Simulating network delay"
```

## Example Configurations

### Configuration 1: Development Testing

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 200,
    "MaxDelayMs": 1000
  }
}
```

### Configuration 2: Load Testing

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 50,
    "MaxDelayMs": 500
  }
}
```

### Configuration 3: Stress Testing

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 1000,
    "MaxDelayMs": 5000
  }
}
```

### Configuration 4: Production Baseline

```json
{
  "DelaySimulation": {
    "Enabled": false
  }
}
```

## Summary

✅ **Delays are already working** - enabled with 500ms fixed delay  
✅ **Easy to customize** - just edit `appsettings.json`  
✅ **Multiple scenarios** - fixed, random, disabled  
✅ **Real-time monitoring** - visible in logs  
✅ **Flexible testing** - change configs without code changes  

**To customize delays:**
1. Edit `appsettings.json`
2. Change values in `DelaySimulation` section
3. Restart proxy: `dotnet run`
4. Watch logs to verify delays

**Current setup:** Every request through the proxy is delayed by 500ms!

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────────┐
│ DELAY CONFIGURATION QUICK REFERENCE                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ Enabled: true/false     ← Turn delays on/off               │
│ UseRandomDelay: false   ← Fixed delay mode                 │
│   FixedDelayMs: 500     ← Delay in milliseconds            │
│                                                             │
│ UseRandomDelay: true    ← Random delay mode                │
│   MinDelayMs: 200       ← Minimum delay                    │
│   MaxDelayMs: 2000      ← Maximum delay                    │
│                                                             │
│ Check: curl localhost:5000/health  ← View current config   │
│ Logs: grep "Simulating" proxy.log  ← See delays applied    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
