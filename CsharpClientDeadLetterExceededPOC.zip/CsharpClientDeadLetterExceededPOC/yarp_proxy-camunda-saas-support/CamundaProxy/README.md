# Camunda Proxy with Network Delay Simulation

A YARP (Yet Another Reverse Proxy) based reverse proxy for .NET 10 that forwards requests to Camunda Run with configurable network delay simulation capabilities.

## Features

- **Reverse Proxy**: Forward all requests to Camunda Run (default: `http://localhost:8080`)
- **Network Delay Simulation**: Simulate network latency for testing purposes
- **Configurable Delays**: Support for both fixed and random delays
- **Health Check**: Built-in health check endpoint
- **.NET 10**: Built on the latest .NET platform

## Prerequisites

- .NET 10 SDK
- Camunda Run running locally on port 8080 (download from https://camunda.com/download/)
  - Or configure a different port in `appsettings.json` if your Camunda runs elsewhere

## Getting Started

### 1. Build the Project

```bash
dotnet build
```

### 2. Run the Proxy

```bash
dotnet run
```

By default, the proxy will listen on:
- HTTP: `http://localhost:5000`
- HTTPS: `https://localhost:5001`

### 3. Access Camunda Through the Proxy

Instead of accessing Camunda directly at `http://localhost:8080`, use the proxy:

```bash
# Direct Camunda access (no delay)
curl http://localhost:8080/engine-rest/version

# Through proxy (with simulated delay)
curl http://localhost:5000/engine-rest/version
```

## Configuration

### Delay Simulation Settings

Edit `appsettings.json` to configure delay simulation:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 1000,
    "MinDelayMs": 500,
    "MaxDelayMs": 3000
  }
}
```

**Configuration Options:**

- **Enabled**: Turn delay simulation on/off (`true`/`false`)
- **UseRandomDelay**: Use random delays vs fixed delay (`true`/`false`)
- **FixedDelayMs**: Fixed delay in milliseconds (used when `UseRandomDelay` is `false`)
- **MinDelayMs**: Minimum delay in milliseconds (used when `UseRandomDelay` is `true`)
- **MaxDelayMs**: Maximum delay in milliseconds (used when `UseRandomDelay` is `true`)

### Camunda Configuration

To change the target Camunda instance, edit the `ReverseProxy` section in `appsettings.json`:

```json
{
  "ReverseProxy": {
    "Clusters": {
      "camunda-cluster": {
        "Destinations": {
          "camunda-instance": {
            "Address": "http://localhost:8080"
          }
        }
      }
    }
  }
}
```

### Development Environment

The `appsettings.Development.json` includes different defaults:
- Random delays enabled
- Delay range: 200-2000ms
- More verbose logging

To run in development mode:

```bash
dotnet run --environment Development
```

## Health Check

Check the proxy status and current delay configuration:

```bash
curl http://localhost:5000/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2025-12-10T22:45:00.000Z",
  "delaySimulation": {
    "enabled": true,
    "useRandomDelay": false,
    "fixedDelayMs": 1000,
    "minDelayMs": 500,
    "maxDelayMs": 3000
  }
}
```

## Use Cases

### 1. Testing Application Resilience

Simulate network delays to test how your application handles slow responses:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 1000,
    "MaxDelayMs": 5000
  }
}
```

### 2. Load Testing with Realistic Latency

Add realistic network latency to your load tests:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": true,
    "MinDelayMs": 50,
    "MaxDelayMs": 200
  }
}
```

### 3. Timeout Testing

Test timeout handling by introducing significant delays:

```json
{
  "DelaySimulation": {
    "Enabled": true,
    "UseRandomDelay": false,
    "FixedDelayMs": 30000
  }
}
```

### 4. Production-like Environment

Disable delays when you need production-like performance:

```json
{
  "DelaySimulation": {
    "Enabled": false
  }
}
```

## Project Structure

```
CamundaProxy/
├── Program.cs                          # Main application entry point
├── DelaySimulationMiddleware.cs        # Custom middleware for delay simulation
├── appsettings.json                    # Production configuration
├── appsettings.Development.json        # Development configuration
├── CamundaProxy.csproj                 # Project file
└── README.md                           # This file
```

## How It Works

1. **Request Flow**: Client → Proxy (with delay) → Camunda Run → Response (with delay) → Client
2. **Delay Middleware**: Applied before YARP routing, simulating network latency
3. **YARP Routing**: Forwards all requests to configured Camunda instance
4. **Logging**: All delays and requests are logged for debugging

## Advanced Configuration

### Custom Routes

You can add specific routes for different behaviors:

```json
{
  "ReverseProxy": {
    "Routes": {
      "api-route": {
        "ClusterId": "camunda-cluster",
        "Match": {
          "Path": "/engine-rest/{**catch-all}"
        }
      },
      "web-route": {
        "ClusterId": "camunda-cluster",
        "Match": {
          "Path": "/camunda/{**catch-all}"
        }
      }
    }
  }
}
```

### Load Balancing

Add multiple Camunda instances for load balancing:

```json
{
  "ReverseProxy": {
    "Clusters": {
      "camunda-cluster": {
        "Destinations": {
          "camunda-instance-1": {
            "Address": "http://localhost:8080"
          },
          "camunda-instance-2": {
            "Address": "http://localhost:8081"
          }
        }
      }
    }
  }
}
```

## Troubleshooting

### Proxy Not Forwarding Requests

- Check that Camunda Run is running on the configured port (default: 8080)
- Verify the `Address` in `appsettings.json` matches your Camunda instance
- Check logs for any YARP routing errors

### Delays Not Working

- Verify `Enabled` is set to `true` in `DelaySimulation` configuration
- Check logs to see if delays are being applied
- Ensure you're accessing through the proxy (e.g., `localhost:5000`) not directly to Camunda

### Connection Refused

- Ensure Camunda Run is started before the proxy
- Check firewall settings
- Verify port numbers in configuration

## License

This project is provided as-is for demonstration purposes.

## References

- [YARP Documentation](https://microsoft.github.io/reverse-proxy/)
- [Camunda Platform](https://camunda.com/)
- [.NET 10 Documentation](https://learn.microsoft.com/dotnet/)
