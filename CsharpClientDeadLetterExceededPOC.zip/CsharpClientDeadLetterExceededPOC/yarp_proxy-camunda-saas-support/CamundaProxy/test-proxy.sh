#!/bin/bash

# Test script for CamundaProxy with delay simulation

echo "======================================"
echo "CamundaProxy Test Script"
echo "======================================"
echo ""

PROXY_URL="http://localhost:5000"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}1. Testing Health Check Endpoint${NC}"
echo "Request: GET $PROXY_URL/health"
echo "---"
START=$(date +%s%3N)
curl -s "$PROXY_URL/health" | json_pp 2>/dev/null || curl -s "$PROXY_URL/health"
END=$(date +%s%3N)
DURATION=$((END - START))
echo ""
echo -e "${GREEN}Response time: ${DURATION}ms${NC}"
echo ""
echo "======================================"
echo ""

echo -e "${YELLOW}2. Testing Proxy to Camunda (with delay simulation)${NC}"
echo "Request: GET $PROXY_URL/engine-rest/version"
echo "Note: This request will include the configured delay"
echo "---"
START=$(date +%s%3N)
curl -s -w "\nHTTP Status: %{http_code}\n" "$PROXY_URL/engine-rest/version"
END=$(date +%s%3N)
DURATION=$((END - START))
echo -e "${GREEN}Total response time (including delay): ${DURATION}ms${NC}"
echo ""
echo "======================================"
echo ""

echo -e "${YELLOW}3. Multiple Requests to See Delay Variation${NC}"
echo "Making 5 requests to observe delay patterns..."
echo "---"
for i in {1..5}; do
    echo -n "Request $i: "
    START=$(date +%s%3N)
    curl -s -o /dev/null -w "HTTP %{http_code}" "$PROXY_URL/health"
    END=$(date +%s%3N)
    DURATION=$((END - START))
    echo -e " - ${GREEN}${DURATION}ms${NC}"
done
echo ""
echo "======================================"
echo ""

echo "Test complete!"
echo ""
echo "Tips:"
echo "  - Check logs to see delay values being applied"
echo "  - Modify appsettings.json to change delay configuration"
echo "  - Use appsettings.Examples.json for different scenarios"
echo ""
