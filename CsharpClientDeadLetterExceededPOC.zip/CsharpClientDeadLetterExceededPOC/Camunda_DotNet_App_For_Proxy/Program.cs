using Grpc.Core;
using Grpc.Net.Client;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using Zeebe.Client;
using Zeebe.Client.Api.Builder;
using Zeebe.Client.Api.Responses;
using Zeebe.Client.Api.Worker;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddEndpointsApiExplorer();

// Configure Camunda/Zeebe client for local Camunda Run
var camundaConfig = builder.Configuration.GetSection("Camunda");
var localConfig = camundaConfig.GetSection("Local");

var gatewayAddress = localConfig["GatewayAddress"] ?? "localhost:26500";

var logger = builder.Services.BuildServiceProvider().GetRequiredService<ILogger<Program>>();
logger.LogInformation("Configuring Zeebe client for Camunda Run...");
logger.LogInformation("Gateway Address: {GatewayAddress}", gatewayAddress);
var loggerFactory = builder.Services.BuildServiceProvider()
    .GetRequiredService<ILoggerFactory>();

// Create Zeebe client with explicit timeout configuration
var zeebeClient = ZeebeClient.Builder()
    .UseLoggerFactory(loggerFactory)
    .UseGatewayAddress(gatewayAddress)
    .UseTransportEncryption()
    .Build();

// Register the Zeebe client as a singleton
builder.Services.AddSingleton<IZeebeClient>(zeebeClient);

// Register the job handler service
builder.Services.AddSingleton<SampleJobHandler>();

// Register connection health checker
builder.Services.AddSingleton<ConnectionHealthChecker>();
builder.Services.AddHostedService<ConnectionHealthMonitorService>();

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    // Development-specific configuration
}

app.UseHttpsRedirection();

// Add health check endpoint that includes connection status
app.MapGet("/health", (ConnectionHealthChecker healthChecker) =>
{
    var status = healthChecker.GetStatus();
    return Results.Ok(new
    {
        status = status.IsHealthy ? "healthy" : "unhealthy",
        connectionStatus = status.ConnectionStatus,
        lastSuccessfulPoll = status.LastSuccessfulPoll,
        lastError = status.LastError,
        consecutiveFailures = status.ConsecutiveFailures,
        timestamp = DateTime.UtcNow
    });
})
.WithName("HealthCheck");

// Start the job worker on application startup
app.Lifetime.ApplicationStarted.Register(() =>
{
    var workerLogger = app.Services.GetRequiredService<ILogger<Program>>();
    var client = app.Services.GetRequiredService<IZeebeClient>();
    var handler = app.Services.GetRequiredService<SampleJobHandler>();
    var healthChecker = app.Services.GetRequiredService<ConnectionHealthChecker>();

    var jobType = camundaConfig["JobType"] ?? "sample-job";
    var workerName = camundaConfig["WorkerName"] ?? "sample-worker";
    var maxJobsActive = int.Parse(camundaConfig["MaxJobsActive"] ?? "5");
    var timeoutInMilliseconds = int.Parse(camundaConfig["TimeoutInMilliseconds"] ?? "10000");
    var pollingTimeoutMs = int.Parse(camundaConfig["PollingTimeoutMs"] ?? "5000");

    workerLogger.LogInformation("Starting Camunda Run job worker...");
    workerLogger.LogInformation("Job Type: {JobType}", jobType);
    workerLogger.LogInformation("Worker Name: {WorkerName}", workerName);
    workerLogger.LogInformation("Job Timeout: {Timeout}ms", timeoutInMilliseconds);
    workerLogger.LogInformation("Polling Timeout: {PollingTimeout}ms", pollingTimeoutMs);

    try
    {
        // Create job workers with enhanced error handling
        var jobWorker = client.NewWorker()
            .JobType(jobType)
            .Handler(async (jobClient, job) =>
            {
                // Mark successful poll
                healthChecker.RecordSuccessfulPoll();
                await handler.HandleJobAsync(jobClient, job);
            })
            .MaxJobsActive(maxJobsActive)
            .Name(workerName)
            .Timeout(TimeSpan.FromMilliseconds(timeoutInMilliseconds))
            .PollInterval(TimeSpan.FromSeconds(1))
            .PollingTimeout(TimeSpan.FromMilliseconds(pollingTimeoutMs))
            .Open();


        workerLogger.LogInformation("Camunda Run job worker started successfully!");
        workerLogger.LogInformation("Worker is listening for jobs of type: {JobType}", jobType);
    }
    catch (Exception ex)
    {
        workerLogger.LogError(ex, "Failed to start Camunda Run job worker");
        healthChecker.RecordError(ex);
        throw;
    }
});

// Graceful shutdown handling
app.Lifetime.ApplicationStopping.Register(() =>
{
    var shutdownLogger = app.Services.GetRequiredService<ILogger<Program>>();
    shutdownLogger.LogInformation("Shutting down Camunda Run job worker...");
});

app.Run();

// Connection Health Checker
public class ConnectionHealthChecker
{
    private DateTime? _lastSuccessfulPoll;
    private Exception? _lastError;
    private int _consecutiveFailures;
    private readonly object _lock = new object();

    public void RecordSuccessfulPoll()
    {
        lock (_lock)
        {
            _lastSuccessfulPoll = DateTime.UtcNow;
            _consecutiveFailures = 0;
            _lastError = null;
        }
    }

    public void RecordError(Exception ex)
    {
        lock (_lock)
        {
            _lastError = ex;
            _consecutiveFailures++;
        }
    }

    public HealthStatus GetStatus()
    {
        lock (_lock)
        {
            var timeSinceLastPoll = _lastSuccessfulPoll.HasValue
                ? DateTime.UtcNow - _lastSuccessfulPoll.Value
                : (TimeSpan?)null;

            var isHealthy = _consecutiveFailures == 0 &&
                           (!timeSinceLastPoll.HasValue || timeSinceLastPoll.Value.TotalSeconds < 30);

            return new HealthStatus
            {
                IsHealthy = isHealthy,
                ConnectionStatus = isHealthy ? "Connected" : "Disconnected/Unhealthy",
                LastSuccessfulPoll = _lastSuccessfulPoll,
                LastError = _lastError?.Message,
                ConsecutiveFailures = _consecutiveFailures
            };
        }
    }
}

public class HealthStatus
{
    public bool IsHealthy { get; set; }
    public string ConnectionStatus { get; set; } = "Unknown";
    public DateTime? LastSuccessfulPoll { get; set; }
    public string? LastError { get; set; }
    public int ConsecutiveFailures { get; set; }
}

// Background service to actively monitor connection health
public class ConnectionHealthMonitorService : BackgroundService
{
    private readonly IZeebeClient _client;
    private readonly ConnectionHealthChecker _healthChecker;
    private readonly ILogger<ConnectionHealthMonitorService> _logger;
    private readonly IConfiguration _configuration;

    public ConnectionHealthMonitorService(
        IZeebeClient client,
        ConnectionHealthChecker healthChecker,
        ILogger<ConnectionHealthMonitorService> logger,
        IConfiguration configuration)
    {
        _client = client;
        _healthChecker = healthChecker;
        _logger = logger;
        _configuration = configuration;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var camundaConfig = _configuration.GetSection("Camunda");
        var healthCheckTimeoutMs = int.Parse(camundaConfig["HealthCheckTimeoutMs"] ?? "3000");
        var healthCheckIntervalMs = int.Parse(camundaConfig["HealthCheckIntervalMs"] ?? "10000");

        _logger.LogInformation("Connection health monitor started");
        _logger.LogInformation("Health check timeout: {Timeout}ms", healthCheckTimeoutMs);
        _logger.LogInformation("Health check interval: {Interval}ms", healthCheckIntervalMs);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // Try to get the topology to verify connection
                // This will throw if the connection is down
                var topology = await _client.TopologyRequest()
                    .Send(TimeSpan.FromMilliseconds(healthCheckTimeoutMs));

                _logger.LogDebug("✓ Connection health check passed - Brokers: {BrokerCount}",
                    topology.Brokers.Count);

                _healthChecker.RecordSuccessfulPoll();
            }
            catch (RpcException ex) when (ex.StatusCode == StatusCode.DeadlineExceeded)
            {
                _logger.LogError(ex,
                    "❌ CONNECTION TIMEOUT! The connection to Camunda timed out after {Timeout}ms. " +
                    "Status: {StatusCode}, Details: {Details}",
                    healthCheckTimeoutMs,
                    ex.StatusCode,
                    ex.Status.Detail);
                _healthChecker.RecordError(ex);
            }
            catch (RpcException ex) when (ex.StatusCode == StatusCode.Unavailable)
            {
                _logger.LogError(ex,
                    "❌ CONNECTION UNAVAILABLE! Cannot reach Camunda server. " +
                    "Status: {StatusCode}, Details: {Details}",
                    ex.StatusCode,
                    ex.Status.Detail);
                _healthChecker.RecordError(ex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ CONNECTION ERROR! Health check failed");
                _healthChecker.RecordError(ex);
            }

            // Check at configured interval
            await Task.Delay(TimeSpan.FromMilliseconds(healthCheckIntervalMs), stoppingToken);
        }

        _logger.LogInformation("Connection health monitor stopped");
    }
}

// Job Handler Implementation
public class SampleJobHandler
{
    private readonly ILogger<SampleJobHandler> _logger;
    private readonly IConfiguration _configuration;

    public SampleJobHandler(ILogger<SampleJobHandler> logger, IConfiguration configuration)
    {
        _logger = logger;
        _configuration = configuration;
    }

    public async Task HandleJobAsync(IJobClient jobClient, IJob job)
    {
        _logger.LogInformation("========================================");
        _logger.LogInformation("Received job: {JobKey}", job.Key);
        _logger.LogInformation("Job Type: {JobType}", job.Type);
        _logger.LogInformation("Process Instance Key: {ProcessInstanceKey}", job.ProcessInstanceKey);
        _logger.LogInformation("Element Instance Key: {ElementInstanceKey}", job.ElementInstanceKey);
        _logger.LogInformation("Worker: {Worker}", job.Worker);

        // Get job variables
        var variables = job.Variables;
        _logger.LogInformation("Job Variables: {Variables}", variables);

        try
        {
            // Simulate some work being done
            // Use configurable delay for testing DEADLINE_EXCEEDED
            var delayMs = _configuration.GetValue<int>("Camunda:HandlerDelayMs", 10000);
            _logger.LogInformation("Processing job for {DelayMs}ms...", delayMs);
            await Task.Delay(delayMs);

            // Example: Process the job and prepare response variables
            var responseVariables = new Dictionary<string, object>
            {
                { "processedAt", DateTime.UtcNow.ToString("o") },
                { "processedBy", job.Worker },
                { "result", "success" },
                { "message", "Job processed successfully by .NET worker" }
            };

            // Serialize to JSON string for Zeebe
            var variablesJson = JsonSerializer.Serialize(responseVariables);

            // Complete the job
            await jobClient.NewCompleteJobCommand(job.Key)
                .Variables(variablesJson)
                .Send();

            _logger.LogInformation("Job {JobKey} completed successfully", job.Key);
            _logger.LogInformation("========================================");
        }
        catch (RpcException ex) when (ex.StatusCode == StatusCode.DeadlineExceeded)
        {
            _logger.LogError(ex,
                "========================================\n" +
                "⏰ DEADLINE_EXCEEDED ERROR!\n" +
                "Job Key: {JobKey}\n" +
                "Status Code: {StatusCode}\n" +
                "Message: {Message}\n" +
                "Details: {Details}\n" +
                "This job will be automatically retried by Camunda\n" +
                "========================================",
                job.Key,
                ex.StatusCode,
                ex.Message,
                ex.Status.Detail);
            // Don't fail the job - let Zeebe retry automatically
            throw; // Re-throw to let the framework handle it
        }
        catch (RpcException ex)
        {
            _logger.LogError(ex,
                "========================================\n" +
                "❌ GRPC ERROR!\n" +
                "Job Key: {JobKey}\n" +
                "Status Code: {StatusCode}\n" +
                "Message: {Message}\n" +
                "========================================",
                job.Key,
                ex.StatusCode,
                ex.Message);

            // Fail the job for non-timeout gRPC errors
            await jobClient.NewFailCommand(job.Key)
                .Retries(job.Retries - 1)
                .ErrorMessage($"gRPC Error: {ex.StatusCode} - {ex.Message}")
                .Send();

            _logger.LogWarning("Job {JobKey} failed and will be retried", job.Key);
            _logger.LogInformation("========================================");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing job {JobKey}", job.Key);

            // Fail the job with error details
            await jobClient.NewFailCommand(job.Key)
                .Retries(job.Retries - 1)
                .ErrorMessage(ex.Message)
                .Send();

            _logger.LogWarning("Job {JobKey} failed and will be retried", job.Key);
            _logger.LogInformation("========================================");
        }
    }
}